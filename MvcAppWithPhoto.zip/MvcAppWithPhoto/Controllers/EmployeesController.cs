﻿using Class_08.Models;
using Class_08.Models.InputModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;

namespace Class_08.Controllers
{
    public class EmployeesController : Controller
    {
		EmployeeDbContext db = new EmployeeDbContext();
        // GET: Employees
        public ActionResult Index()
        {
            return View(db.Employees.ToList());
        }
		public ActionResult Create()
		{
			return View();
		}
		[HttpPost]
		public ActionResult Create(Employee emp, HttpPostedFileBase Picture)
		{
			if (emp.Picture !=null && Picture.ContentLength > 0)
			{
				string ext = Path.GetExtension(Picture.FileName);
				string f = Guid.NewGuid() + ext;
				Picture.SaveAs(HostingEnvironment.MapPath("~/Avatars/" + f));
				emp.Picture = f;
			}
			if (ModelState.IsValid)
			{
				db.Employees.Add(emp);
				db.SaveChanges();
				return RedirectToAction("Index");
			}
			return View(emp);
		}
		public ActionResult CreateV1()
		{
			return View();
		}
		[HttpPost]
		public ActionResult CreateV1(EmployeeViewModel emp)
		{
			string f = "p1.png";
			if (emp.Picture != null && emp.Picture.ContentLength > 0)
			{
				string ext = Path.GetExtension(emp.Picture.FileName);
				f = Guid.NewGuid() + ext;
				emp.Picture.SaveAs(HostingEnvironment.MapPath("~/Avatars/" + f));				
			}
			if (ModelState.IsValid)
			{
				db.Employees.Add(new Employee { EmployeeName=emp.EmployeeName, BasicSalary=emp.BasicSalary, Picture =f});
				db.SaveChanges();
				return RedirectToAction("Index");
			}
			return View(emp);		
		}
		public ActionResult Edit(int id)
		{
			return View(db.Employees.First(x => x.EmployeeId == id));
		}
		[HttpPost]
		public ActionResult Edit(Employee emp, HttpPostedFileBase Picture)
		{
			if (emp.Picture != null && Picture.ContentLength > 0)
			{
				string ext = Path.GetExtension(Picture.FileName);
				string f = Guid.NewGuid() + ext;
				Picture.SaveAs(HostingEnvironment.MapPath("~/Avatars/" + f));
				emp.Picture = f;
			}
			if (ModelState.IsValid)
			{
				db.Entry(emp).State = System.Data.Entity.EntityState.Modified;
				db.SaveChanges();
				return RedirectToAction("Index");
			}
			return View(emp);			
		}
		public ActionResult Delete(int id)
		{
			var emp = db.Employees.First(x => x.EmployeeId == id);
			return View(emp);
		}
		[HttpPost, ActionName("Delete")]
		public ActionResult DeleteConfirm(int id)
		{
			var emp = new Employee { EmployeeId = id };
			db.Entry(emp).State = System.Data.Entity.EntityState.Deleted;
			db.SaveChanges();
			return RedirectToAction("Index");
		}
	}
}