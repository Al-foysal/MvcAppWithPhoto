﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Class_08.Models
{
	public class Employee
	{
		public int EmployeeId { get; set; }
		[Required(ErrorMessage = "Id required"), StringLength(50, ErrorMessage ="Max 50 chars is allow"),
			Display(Name ="Emp. Name")]
		public string EmployeeName { get; set; }
		[Required, Column(TypeName = "money"), Display(Name ="Basic Salary"), DisplayFormat(DataFormatString = "{0:0.00}", 
			ApplyFormatInEditMode = true)]
		public decimal BasicSalary { get; set; } 
		[Required,StringLength(150)]
		public string Picture { get; set; }
	}
	public class EmployeeDbContext : DbContext
	{
		public DbSet<Employee> Employees { get; set; }
	}
}