﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Class_08.Models.InputModel
{
	public class EmployeeViewModel
	{
		[Key]
		public int EmployeeId { get; set; }
		[Required(ErrorMessage = "Id required"), StringLength(50, ErrorMessage = "Max 50 chars is allow"),
			Display(Name = "Emp. Name")]
		public string EmployeeName { get; set; }
		[Required, Column(TypeName = "money"), Display(Name = "Basic Salary"), DisplayFormat(DataFormatString = "{0:0.00}",
			ApplyFormatInEditMode = true)]
		public decimal BasicSalary { get; set; }
		
		public HttpPostedFileBase Picture { get; set; }
	}
}